export const baseUrl = "https://backend-3d-exclusive.vercel.app/api";

// https://backend-3d-exclusive.vercel.app/api
// http://localhost:3000/api