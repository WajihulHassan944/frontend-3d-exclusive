import { loadStripe } from '@stripe/stripe-js';

export const stripePromise = loadStripe(
  'pk_test_51RbDpx4ainXKK2PaAxl5ehcVkFSyLD4sI6ueZSndoFYKIhko16nsHOnvJznN0YTogJsBezhZSYCJxXW9fLjWzAgY00cv05me5D'
);
